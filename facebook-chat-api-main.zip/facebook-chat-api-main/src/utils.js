"use strict";

module.exports = {
  // Dummy logMessage to avoid error
  logMessage: function (data) {
    console.log("Received message delta:", data);
  }
};
